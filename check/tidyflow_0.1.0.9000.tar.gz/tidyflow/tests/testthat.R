library(testthat)
library(tidyflow)

test_check("tidyflow")
